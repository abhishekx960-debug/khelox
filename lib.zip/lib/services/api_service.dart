import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Backend folder URL (HTTPS zaroori, trailing slash nahi).
const String kApiBaseUrl = 'https://blackxmarket.shop/KheloX/khelox-backend';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class UserModel {
  final int id;
  final String name;
  final String email;
  final String phone;
  final double fcoin;
  final double dcoin;
  final double wcoin;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.fcoin = 0,
    this.dcoin = 0,
    this.wcoin = 0,
  });

  static double _d(dynamic v) => double.tryParse('${v ?? 0}') ?? 0;

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
        id: int.parse(j['id'].toString()),
        name: j['name'].toString(),
        email: j['email'].toString(),
        phone: j['phone'].toString(),
        fcoin: _d(j['fcoin']),
        dcoin: _d(j['dcoin']),
        wcoin: _d(j['wcoin']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'fcoin': fcoin,
        'dcoin': dcoin,
        'wcoin': wcoin,
      };
}

class ApiService {
  static Future<Map<String, dynamic>> _post(
    String endpoint,
    Map<String, dynamic> body,
  ) async {
    try {
      final res = await http
          .post(
            Uri.parse('$kApiBaseUrl/$endpoint'),
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['success'] == true) return data;
      throw ApiException(data['message']?.toString() ?? 'Something went wrong');
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw ApiException('Server slow hai. Dobara try karo.');
    } on SocketException {
      throw ApiException('Internet connection check karo.');
    } on FormatException {
      throw ApiException('Server se galat response aaya.');
    }
  }

  static Future<UserModel> login({
    required String email,
    required String password,
  }) async {
    final data = await _post('login.php', {
      'email': email.trim(),
      'password': password,
    });
    return UserModel.fromJson(data['user'] as Map<String, dynamic>);
  }

  static Future<UserModel> register({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    final data = await _post('register.php', {
      'name': name.trim(),
      'email': email.trim(),
      'phone': phone.trim(),
      'password': password,
    });
    return UserModel.fromJson(data['user'] as Map<String, dynamic>);
  }

  static Future<UserModel> fetchUser(int id) async {
    final data = await _post('user.php', {'id': id});
    return UserModel.fromJson(data['user'] as Map<String, dynamic>);
  }
}

class SessionService {
  static const _key = 'khelox_user';

  static Future<void> save(UserModel user) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(user.toJson()));
  }

  static Future<UserModel?> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return null;
    try {
      return UserModel.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
  }
}


/// Global realtime user/balance holder.
/// Poll har 10 sec + app resume pe refresh. UI ValueListenableBuilder se sune.
class UserStore with WidgetsBindingObserver {
  UserStore._();
  static final UserStore instance = UserStore._();

  static const _interval = Duration(seconds: 10);

  final ValueNotifier<UserModel?> user = ValueNotifier(null);
  Timer? _timer;
  bool _busy = false;

  void start(UserModel u) {
    user.value = u;
    WidgetsBinding.instance.removeObserver(this);
    WidgetsBinding.instance.addObserver(this);
    _startTimer();
    refresh();
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    WidgetsBinding.instance.removeObserver(this);
    user.value = null;
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(_interval, (_) => refresh());
  }

  /// Game reward / match entry ke baad bhi ye call kar sakte ho.
  /// silent=false → error upar throw (pull-to-refresh me msg dikhane ke liye).
  Future<void> refresh({bool silent = true}) async {
    final u = user.value;
    if (u == null || _busy) return;
    _busy = true;
    try {
      final fresh = await ApiService.fetchUser(u.id);
      if (user.value == null) return; // logout ho gaya beech me
      user.value = fresh;
      await SessionService.save(fresh);
    } catch (e) {
      debugPrint('UserStore.refresh failed: $e');
      if (!silent) rethrow;
    } finally {
      _busy = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      refresh();
      _startTimer();
    } else if (state == AppLifecycleState.paused) {
      _timer?.cancel();
    }
  }
}